var notify = require("gulp-notify");

module.exports = function(gulp, callback) {
	return notify("HTML Build Complete!!");
};